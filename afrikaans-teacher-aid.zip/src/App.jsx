import React, { useState } from 'react'

export default function App() {
  const [words, setWords] = useState([{af: 'huis', en: 'house'}])
  const [newAf, setNewAf] = useState('')
  const [newEn, setNewEn] = useState('')

  const addWord = () => {
    if(newAf && newEn) {
      setWords([...words, {af: newAf, en: newEn}])
      setNewAf('')
      setNewEn('')
    }
  }

  return (
    <div className="p-6 max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Afrikaans Teacher Aid</h1>

      <div className="mb-4">
        <input
          type="text"
          placeholder="Afrikaans"
          value={newAf}
          onChange={(e) => setNewAf(e.target.value)}
          className="border p-2 mr-2"
        />
        <input
          type="text"
          placeholder="English"
          value={newEn}
          onChange={(e) => setNewEn(e.target.value)}
          className="border p-2 mr-2"
        />
        <button onClick={addWord} className="bg-blue-500 text-white px-4 py-2 rounded">Add</button>
      </div>

      <ul className="list-disc pl-5">
        {words.map((w, i) => (
          <li key={i}>{w.af} → {w.en}</li>
        ))}
      </ul>
    </div>
  )
}